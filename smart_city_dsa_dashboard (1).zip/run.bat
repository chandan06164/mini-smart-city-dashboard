@echo off
title Smart City Operations Engine - DSA Dashboard
color 0B
cls

:MENU
echo ======================================================================
echo    CITY OF TOMORROW - MUNICIPAL SERVICES DSA DASHBOARD (PYTHON)
echo ======================================================================
echo.
echo   [1] Launch Interactive Web Dashboard in Browser  (python app.py)
echo   [2] Launch Native Desktop GUI Window             (python gui_app.py)
echo   [3] Run Full Terminal Simulation & Output        (python smart_city.py)
echo   [4] Run Automated Unit Tests                     (python test_smart_city.py)
echo   [5] Exit
echo.
echo ======================================================================
set /p choice="Select an option [1-5]: "

if "%choice%"=="1" (
    echo.
    echo Starting Web Server at http://127.0.0.1:8000 and opening browser...
    python app.py
    pause
    goto MENU
)
if "%choice%"=="2" (
    echo.
    echo Launching Native Tkinter Desktop GUI...
    python gui_app.py
    goto MENU
)
if "%choice%"=="3" (
    echo.
    echo Running Terminal Simulation Engine...
    python smart_city.py
    echo.
    pause
    goto MENU
)
if "%choice%"=="4" (
    echo.
    echo Running Test Suite...
    python test_smart_city.py
    echo.
    pause
    goto MENU
)
if "%choice%"=="5" (
    exit
)

echo Invalid choice, please try again.
pause
goto MENU
