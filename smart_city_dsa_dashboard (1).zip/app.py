"""
Smart City Service Dashboard - Python Backend & Web Server
Powered entirely by Python Standard Library (http.server, json, urllib, webbrowser).
Connects front-end UI directly to in-memory Python Data Structures.
"""

import sys
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

import http.server
import json
import os
import urllib.parse
import webbrowser
from typing import Dict, Any

from smart_city import (
    TrafficGraph,
    EmergencyDispatchQueue,
    EmergencyIncident,
    MetroTransitLine,
    MunicipalHashTable,
    CitizenTokenQueue,
    AuditRollbackStack,
    PowerGridNode,
)

# =====================================================================
# GLOBAL STATE INITIALIZATION
# =====================================================================
def create_initial_state():
    # 1. Traffic Graph
    traffic = TrafficGraph()
    intersections = [
        ("A", "Downtown Core"),
        ("B", "North Hills"),
        ("C", "Civic Square"),
        ("D", "Airport Junction"),
        ("E", "Harbor District"),
        ("F", "Tech Park")
    ]
    for nid, label in intersections:
        traffic.add_intersection(nid, label)

    traffic.add_road("A", "B", 4.0)
    traffic.add_road("A", "C", 3.0)
    traffic.add_road("B", "C", 2.0)
    traffic.add_road("B", "D", 5.0)
    traffic.add_road("C", "E", 6.0)
    traffic.add_road("C", "F", 8.0)
    traffic.add_road("D", "F", 3.0)
    traffic.add_road("E", "F", 2.0)
    traffic.add_road("B", "E", 7.0)

    # 2. Emergency Heap
    dispatch = EmergencyDispatchQueue()
    dispatch.enqueue_incident(EmergencyIncident("E-1", 1, "Acute Cardiac Arrest", "Sector Downtown"))
    dispatch.enqueue_incident(EmergencyIncident("E-2", 2, "Structure Fire", "Sector North"))
    dispatch.enqueue_incident(EmergencyIncident("E-3", 3, "Gas Smell Report", "Sector Industrial"))
    dispatch.enqueue_incident(EmergencyIncident("E-4", 4, "Fallen Tree Branch", "Sector East"))
    dispatch.enqueue_incident(EmergencyIncident("E-5", 2, "Vehicular Collision", "Sector Downtown"))

    # 3. Metro DLL
    metro = MetroTransitLine()
    for station in ["Central Terminal", "Civic Center", "Financial District", "West Harbor", "Airport Terminus"]:
        metro.append_station(station)
    metro.current_train = metro.head.next  # Start at Civic Center

    # 4. Hash Table
    registry = MunicipalHashTable(capacity=8)
    registry.set("CITY-1011", {"owner": "David Kim (Ambulance 04)", "status": "Priority Fleet"})
    registry.set("CITY-9042", {"owner": "Elena Rostova (Transit Van)", "status": "Valid Permit"})
    registry.set("CITY-3320", {"owner": "Metro Electric Grid Van", "status": "Municipal Utility"})
    registry.set("CITY-7741", {"owner": "Sarah Jenkins (Solar EV)", "status": "EV Toll Exemption"})
    registry.set("CITY-8910", {"owner": "Urban Logistics Hauler", "status": "Unpaid Fine (Flagged)"})

    # 5. Service Desk (Queue + Stack)
    token_queue = CitizenTokenQueue()
    token_queue.enqueue("T-101", "Marcus Vance", "Permit")
    token_queue.enqueue("T-102", "Aria Thorne", "Water")
    token_queue.enqueue("T-103", "Leo Zhang", "Tax")
    token_queue.enqueue("T-104", "Fatima Al-Sayed", "Permit")

    audit_stack = AuditRollbackStack()
    audit_stack.push_action("Granted Solar Building Permit #409", "Inspector Vance")
    audit_stack.push_action("Waived Overdue Parking Late Fee", "Clerk Jensen")
    audit_stack.push_action("Updated Commercial Water Meter #12", "Agent Diaz")

    # 6. Power Grid Tree
    power_plant = PowerGridNode("root", "Metropolitan Hydro Plant")
    sub1 = PowerGridNode("sub-1", "North Substation")
    sub2 = PowerGridNode("sub-2", "Central Grid Station")
    sub3 = PowerGridNode("sub-3", "South Substation")

    feeder1a = PowerGridNode("feeder-1a", "Residential Feeder A")
    feeder1b = PowerGridNode("feeder-1b", "Civic Hospital Transformer")
    sub1.add_child(feeder1a)
    sub1.add_child(feeder1b)

    feeder2a = PowerGridNode("feeder-2a", "Downtown Commercial Tower")
    sub2.add_child(feeder2a)

    feeder3a = PowerGridNode("feeder-3a", "Harbor Freight Yard")
    feeder3b = PowerGridNode("feeder-3b", "Tech Zone Cleanrooms")
    sub3.add_child(feeder3a)
    sub3.add_child(feeder3b)

    power_plant.add_child(sub1)
    power_plant.add_child(sub2)
    power_plant.add_child(sub3)

    return {
        "traffic": traffic,
        "dispatch": dispatch,
        "metro": metro,
        "registry": registry,
        "token_queue": token_queue,
        "audit_stack": audit_stack,
        "power_tree": power_plant,
        "ops_count": 142
    }


STATE = create_initial_state()


def serialize_tree(node: PowerGridNode) -> Dict[str, Any]:
    return {
        "id": node.id,
        "name": node.name,
        "status": node.is_online,
        "children": [serialize_tree(c) for c in node.children]
    }


def serialize_metro(metro: MetroTransitLine) -> Dict[str, Any]:
    stations = []
    curr = metro.head
    curr_idx = 0
    active_idx = 0
    while curr:
        if curr == metro.current_train:
            active_idx = curr_idx
        stations.append({
            "name": curr.name,
            "passengers": curr.commuters_waiting
        })
        curr = curr.next
        curr_idx += 1
    return {
        "stations": stations,
        "active_index": active_idx,
        "current_name": metro.current_train.name if metro.current_train else None,
        "prev_name": metro.current_train.prev.name if metro.current_train and metro.current_train.prev else "NULL",
        "next_name": metro.current_train.next.name if metro.current_train and metro.current_train.next else "NULL"
    }


def serialize_hash_table(ht: MunicipalHashTable) -> Dict[str, Any]:
    buckets_data = []
    for b in ht.buckets:
        buckets_data.append([{"key": item.key, "value": item.value} for item in b])
    return {
        "capacity": ht.capacity,
        "count": ht.count,
        "load_factor": round(ht.load_factor(), 3),
        "buckets": buckets_data
    }


def serialize_full_state() -> Dict[str, Any]:
    # Heap array
    heap_list = [
        {"id": inc.incident_id, "priority": inc.priority, "description": inc.description, "sector": inc.sector}
        for inc in STATE["dispatch"].heap
    ]
    online, total = STATE["power_tree"].count_operational()

    return {
        "ops_count": STATE["ops_count"],
        "heap": heap_list,
        "metro": serialize_metro(STATE["metro"]),
        "registry": serialize_hash_table(STATE["registry"]),
        "queue": STATE["token_queue"].items,
        "stack": STATE["audit_stack"].stack,
        "power_tree": serialize_tree(STATE["power_tree"]),
        "power_stats": {"online": online, "total": total}
    }


# =====================================================================
# HTTP REQUEST HANDLER
# =====================================================================
class SmartCityAPIHandler(http.server.BaseHTTPRequestHandler):

    def _set_headers(self, status: int = 200, content_type: str = "application/json"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_OPTIONS(self):
        self._set_headers(200)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        if path == "/" or path == "/index.html":
            file_path = os.path.join(os.path.dirname(__file__), "index.html")
            if os.path.exists(file_path):
                self._set_headers(200, "text/html; charset=utf-8")
                with open(file_path, "rb") as f:
                    self.wfile.write(f.read())
            else:
                self._set_headers(404, "text/plain")
                self.wfile.write(b"index.html not found.")
            return

        if path == "/api/state":
            self._set_headers(200)
            self.wfile.write(json.dumps(serialize_full_state()).encode("utf-8"))
            return

        if path == "/api/registry/lookup":
            key = query.get("key", [""])[0].strip().upper()
            val = STATE["registry"].get(key)
            hash_idx = STATE["registry"]._hash(key) if key else 0
            STATE["ops_count"] += 1
            self._set_headers(200)
            self.wfile.write(json.dumps({
                "found": val is not None,
                "key": key,
                "bucket": hash_idx,
                "value": val
            }).encode("utf-8"))
            return

        self._set_headers(404, "application/json")
        self.wfile.write(json.dumps({"error": "Endpoint not found"}).encode("utf-8"))

    def do_POST(self):
        global STATE
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        content_len = int(self.headers.get("Content-Length", 0))
        post_body = self.rfile.read(content_len) if content_len > 0 else b"{}"

        try:
            payload = json.loads(post_body.decode("utf-8")) if post_body else {}
        except Exception:
            payload = {}

        STATE["ops_count"] += 1

        # 1. Dijkstra Pathfinding
        if path == "/api/traffic/dijkstra":
            start = payload.get("start", "A")
            dest = payload.get("dest", "F")
            cost, route = STATE["traffic"].dijkstra_shortest_path(start, dest)
            self._set_headers(200)
            self.wfile.write(json.dumps({
                "start": start,
                "dest": dest,
                "cost_minutes": cost,
                "distance_km": round(cost * 1.8, 1) if cost != float("inf") else 0,
                "route": route
            }).encode("utf-8"))
            return

        # 2. Emergency Enqueue / Dequeue
        if path == "/api/emergency/enqueue":
            prio = int(payload.get("priority", 2))
            desc = payload.get("description", "Alert")
            sector = payload.get("sector", "Sector Downtown")
            inc_id = f"E-{len(STATE['dispatch'].heap) + 101}"
            STATE["dispatch"].enqueue_incident(EmergencyIncident(inc_id, prio, desc, sector))
            self._set_headers(200)
            self.wfile.write(json.dumps(serialize_full_state()).encode("utf-8"))
            return

        if path == "/api/emergency/dispatch":
            dispatched = STATE["dispatch"].dispatch_highest_urgency()
            self._set_headers(200)
            self.wfile.write(json.dumps({
                "dispatched": {
                    "id": dispatched.incident_id,
                    "priority": dispatched.priority,
                    "description": dispatched.description,
                    "sector": dispatched.sector
                } if dispatched else None,
                "state": serialize_full_state()
            }).encode("utf-8"))
            return

        # 3. Metro Operations
        if path == "/api/metro/next":
            STATE["metro"].move_train_next()
            self._set_headers(200)
            self.wfile.write(json.dumps(serialize_full_state()).encode("utf-8"))
            return

        if path == "/api/metro/prev":
            STATE["metro"].move_train_prev()
            self._set_headers(200)
            self.wfile.write(json.dumps(serialize_full_state()).encode("utf-8"))
            return

        if path == "/api/metro/add":
            name = payload.get("name", "New Station")
            pos = payload.get("position", "end")
            new_node = STATE["metro"].append_station(name)
            self._set_headers(200)
            self.wfile.write(json.dumps(serialize_full_state()).encode("utf-8"))
            return

        if path == "/api/metro/remove":
            if STATE["metro"].current_train:
                STATE["metro"].remove_station(STATE["metro"].current_train)
            self._set_headers(200)
            self.wfile.write(json.dumps(serialize_full_state()).encode("utf-8"))
            return

        # 4. Hash Table Set
        if path == "/api/registry/insert":
            key = payload.get("key", "").strip().upper()
            val = payload.get("value", {})
            if key:
                STATE["registry"].set(key, val)
            self._set_headers(200)
            self.wfile.write(json.dumps(serialize_full_state()).encode("utf-8"))
            return

        # 5. Service Queue & Undo Stack
        if path == "/api/service/enqueue":
            name = payload.get("name", "Citizen")
            dept = payload.get("dept", "Permit")
            tid = f"T-{len(STATE['token_queue'].items) + 201}"
            STATE["token_queue"].enqueue(tid, name, dept)
            self._set_headers(200)
            self.wfile.write(json.dumps(serialize_full_state()).encode("utf-8"))
            return

        if path == "/api/service/dequeue":
            served = STATE["token_queue"].dequeue()
            if served:
                STATE["audit_stack"].push_action(
                    f"Processed {served['dept']} for {served['name']} ({served['id']})",
                    "Counter Agent 01"
                )
            self._set_headers(200)
            self.wfile.write(json.dumps({
                "served": served,
                "state": serialize_full_state()
            }).encode("utf-8"))
            return

        if path == "/api/service/undo":
            undone = STATE["audit_stack"].pop_undo()
            self._set_headers(200)
            self.wfile.write(json.dumps({
                "undone": undone,
                "state": serialize_full_state()
            }).encode("utf-8"))
            return

        # 6. Power Grid Toggle / Restore
        if path == "/api/power/toggle":
            target_id = payload.get("id")

            def toggle_node(node: PowerGridNode) -> bool:
                if node.id == target_id:
                    node.set_cascade_status(not node.is_online)
                    return True
                for c in node.children:
                    if toggle_node(c):
                        return True
                return False

            toggle_node(STATE["power_tree"])
            self._set_headers(200)
            self.wfile.write(json.dumps(serialize_full_state()).encode("utf-8"))
            return

        if path == "/api/power/restore":
            STATE["power_tree"].set_cascade_status(True)
            self._set_headers(200)
            self.wfile.write(json.dumps(serialize_full_state()).encode("utf-8"))
            return

        if path == "/api/reset":
            STATE = create_initial_state()
            self._set_headers(200)
            self.wfile.write(json.dumps(serialize_full_state()).encode("utf-8"))
            return

        self._set_headers(404, "application/json")
        self.wfile.write(json.dumps({"error": "Unknown API route"}).encode("utf-8"))


# =====================================================================
# SERVER RUNNER
# =====================================================================
def run_server(port: int = 8000, auto_open: bool = True):
    server_address = ("127.0.0.1", port)
    try:
        httpd = http.server.ThreadingHTTPServer(server_address, SmartCityAPIHandler)
    except OSError:
        port = 8080
        server_address = ("127.0.0.1", port)
        httpd = http.server.ThreadingHTTPServer(server_address, SmartCityAPIHandler)

    url = f"http://127.0.0.1:{port}"
    print("=" * 70)
    print("🏙️  SMART CITY SERVICE DASHBOARD - PYTHON SERVER RUNNING")
    print(f"🔗 Local Web Dashboard: {url}")
    print("⚡ Connected to live Python DSA in-memory engine")
    print("   - Graph (Dijkstra): /api/traffic/dijkstra")
    print("   - Binary Min-Heap:  /api/emergency/dispatch")
    print("   - Doubly Linked:    /api/metro/*")
    print("   - Hash Table:       /api/registry/*")
    print("   - Queue & Stack:    /api/service/*")
    print("   - N-ary Tree:       /api/power/*")
    print("=" * 70)
    print("Press Ctrl+C to stop server.\n")

    if auto_open:
        webbrowser.open(url)

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping Python SmartCity Server...")
        httpd.server_close()


if __name__ == "__main__":
    should_open = "--no-browser" not in sys.argv
    port_arg = 8000
    for arg in sys.argv:
        if arg.startswith("--port="):
            port_arg = int(arg.split("=")[1])
    run_server(port=port_arg, auto_open=should_open)
