# Smart City DSA Dashboard - PowerShell Launcher
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "   🏙️  SMART CITY MUNICIPAL SERVICES DSA DASHBOARD (PYTHON)" -ForegroundColor Cyan
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  [1] Launch Interactive Web Dashboard in Browser  (python app.py)" -ForegroundColor Yellow
Write-Host "  [2] Launch Native Desktop GUI Window             (python gui_app.py)" -ForegroundColor Yellow
Write-Host "  [3] Run Full Terminal Simulation & Output        (python smart_city.py)" -ForegroundColor Yellow
Write-Host "  [4] Run Automated Unit Tests                     (python test_smart_city.py)" -ForegroundColor Yellow
Write-Host "  [5] Exit" -ForegroundColor Red
Write-Host ""
Write-Host "======================================================================" -ForegroundColor Cyan

$choice = Read-Host "Select an option [1-5]"

switch ($choice) {
    "1" {
        Write-Host "`nStarting Web Server at http://127.0.0.1:8000 and opening browser..." -ForegroundColor Green
        python app.py
    }
    "2" {
        Write-Host "`nLaunching Native Desktop GUI (Tkinter)..." -ForegroundColor Green
        python gui_app.py
    }
    "3" {
        Write-Host "`nRunning Terminal Simulation Engine..." -ForegroundColor Green
        python smart_city.py
    }
    "4" {
        Write-Host "`nRunning Test Suite..." -ForegroundColor Green
        python test_smart_city.py -v
    }
    Default {
        Write-Host "`nExiting."
    }
}
