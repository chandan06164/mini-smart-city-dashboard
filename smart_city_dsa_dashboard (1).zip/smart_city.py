"""
Smart City Municipal Operations Engine - Data Structures & Algorithms Implementation
Demonstrating real-world civil infrastructure mapped to fundamental DSA concepts.
"""

import sys
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
from typing import Dict, List, Optional, Tuple, Any
import heapq


# =====================================================================
# 1. TRAFFIC MANAGEMENT & NAVIGATION -> WEIGHTED DIRECTED GRAPH
# =====================================================================
class TrafficGraph:
    """
    Weighted Graph representation using an Adjacency List.
    Algorithm: Dijkstra's Algorithm for Shortest Path Navigation.
    Time Complexity: O((V + E) log V) with Priority Queue.
    """
    def __init__(self):
        self.adj_list: Dict[str, List[Tuple[str, float]]] = {}
        self.intersections: Dict[str, str] = {}

    def add_intersection(self, node_id: str, label: str):
        if node_id not in self.adj_list:
            self.adj_list[node_id] = []
            self.intersections[node_id] = label

    def add_road(self, u: str, v: str, travel_time_mins: float, bidirectional: bool = True):
        self.add_intersection(u, u)
        self.add_intersection(v, v)
        self.adj_list[u].append((v, travel_time_mins))
        if bidirectional:
            self.adj_list[v].append((u, travel_time_mins))

    def dijkstra_shortest_path(self, start: str, destination: str) -> Tuple[float, List[str]]:
        """Computes fastest route from start to destination."""
        distances: Dict[str, float] = {node: float('inf') for node in self.adj_list}
        previous: Dict[str, Optional[str]] = {node: None for node in self.adj_list}
        distances[start] = 0.0

        # Min-heap storing tuples of (accumulated_cost, node_id)
        pq: List[Tuple[float, str]] = [(0.0, start)]

        while pq:
            curr_dist, curr_node = heapq.heappop(pq)

            if curr_dist > distances[curr_node]:
                continue

            if curr_node == destination:
                break

            for neighbor, weight in self.adj_list[curr_node]:
                alt_dist = curr_dist + weight
                if alt_dist < distances[neighbor]:
                    distances[neighbor] = alt_dist
                    previous[neighbor] = curr_node
                    heapq.heappush(pq, (alt_dist, neighbor))

        # Reconstruct path
        path: List[str] = []
        curr = destination
        while curr:
            path.append(curr)
            curr = previous[curr]
        path.reverse()

        if not path or path[0] != start:
            return float('inf'), []
        return distances[destination], path


# =====================================================================
# 2. EMERGENCY 911 DISPATCH -> BINARY MIN-HEAP (PRIORITY QUEUE)
# =====================================================================
class EmergencyIncident:
    def __init__(self, incident_id: str, priority_code: int, description: str, sector: str):
        # Code 1: Life-threatening (Critical), Code 2: Urgent, Code 3: Non-urgent
        self.incident_id = incident_id
        self.priority = priority_code
        self.description = description
        self.sector = sector

    def __lt__(self, other: 'EmergencyIncident') -> bool:
        return self.priority < other.priority

    def __repr__(self) -> str:
        return f"[P{self.priority}] {self.description} ({self.sector})"


class EmergencyDispatchQueue:
    """
    Min-Heap Priority Queue.
    Extract-Min: O(log N) - Ensures highest urgency call is served first.
    Insert: O(log N) - Logarithmic bubble-up.
    """
    def __init__(self):
        self.heap: List[EmergencyIncident] = []

    def enqueue_incident(self, incident: EmergencyIncident):
        heapq.heappush(self.heap, incident)

    def dispatch_highest_urgency(self) -> Optional[EmergencyIncident]:
        if not self.heap:
            return None
        return heapq.heappop(self.heap)

    def size(self) -> int:
        return len(self.heap)


# =====================================================================
# 3. METRO TRANSIT LINE -> DOUBLY LINKED LIST
# =====================================================================
class StationNode:
    def __init__(self, name: str, commuters_waiting: int = 150):
        self.name = name
        self.commuters_waiting = commuters_waiting
        self.prev: Optional['StationNode'] = None
        self.next: Optional['StationNode'] = None


class MetroTransitLine:
    """
    Doubly Linked List representing a bidirectional urban transit track.
    Next/Prev Station Traversal: O(1)
    Insert/Delete Station Node: O(1) once pointer is reached.
    """
    def __init__(self):
        self.head: Optional[StationNode] = None
        self.tail: Optional[StationNode] = None
        self.current_train: Optional[StationNode] = None

    def append_station(self, name: str, commuters: int = 200) -> StationNode:
        new_node = StationNode(name, commuters)
        if not self.head:
            self.head = new_node
            self.tail = new_node
            self.current_train = new_node
        else:
            assert self.tail is not None
            self.tail.next = new_node
            new_node.prev = self.tail
            self.tail = new_node
        return new_node

    def move_train_next(self) -> Optional[StationNode]:
        if self.current_train and self.current_train.next:
            self.current_train = self.current_train.next
            return self.current_train
        return None

    def move_train_prev(self) -> Optional[StationNode]:
        if self.current_train and self.current_train.prev:
            self.current_train = self.current_train.prev
            return self.current_train
        return None

    def remove_station(self, target_node: StationNode):
        if target_node.prev:
            target_node.prev.next = target_node.next
        else:
            self.head = target_node.next

        if target_node.next:
            target_node.next.prev = target_node.prev
        else:
            self.tail = target_node.prev

        if self.current_train == target_node:
            self.current_train = target_node.next or target_node.prev or self.head


# =====================================================================
# 4. VEHICLE & CITIZEN ASSET REGISTRY -> HASH TABLE WITH CHAINING
# =====================================================================
class HashBucketItem:
    def __init__(self, key: str, value: Any):
        self.key = key
        self.value = value


class MunicipalHashTable:
    """
    Hash Table with Separate Chaining (Linked collision buckets).
    Lookup / Insert: Average O(1), Worst O(N) if pathological collision.
    """
    def __init__(self, capacity: int = 8):
        self.capacity = capacity
        self.buckets: List[List[HashBucketItem]] = [[] for _ in range(capacity)]
        self.count = 0

    def _hash(self, key: str) -> int:
        hash_val = 0
        for char in key:
            hash_val = (hash_val * 31 + ord(char)) % self.capacity
        return hash_val

    def set(self, key: str, value: Any):
        idx = self._hash(key)
        for item in self.buckets[idx]:
            if item.key == key:
                item.value = value
                return
        self.buckets[idx].append(HashBucketItem(key, value))
        self.count += 1

    def get(self, key: str) -> Optional[Any]:
        idx = self._hash(key)
        for item in self.buckets[idx]:
            if item.key == key:
                return item.value
        return None

    def load_factor(self) -> float:
        return self.count / self.capacity


# =====================================================================
# 5. CITIZEN SERVICE DESK -> FIFO QUEUE & LIFO STACK
# =====================================================================
class CitizenTokenQueue:
    """
    FIFO Queue for fair municipal appointment processing.
    Enqueue: O(1), Dequeue: O(1).
    """
    def __init__(self):
        self.items: List[Dict[str, str]] = []

    def enqueue(self, token_id: str, citizen_name: str, department: str):
        self.items.append({"id": token_id, "name": citizen_name, "dept": department})

    def dequeue(self) -> Optional[Dict[str, str]]:
        if not self.items:
            return None
        return self.items.pop(0)

    def is_empty(self) -> bool:
        return len(self.items) == 0


class AuditRollbackStack:
    """
    LIFO Stack for transactional administrative undo.
    Push: O(1), Pop: O(1).
    """
    def __init__(self):
        self.stack: List[Dict[str, str]] = []

    def push_action(self, action_name: str, operator: str):
        self.stack.append({"action": action_name, "operator": operator})

    def pop_undo(self) -> Optional[Dict[str, str]]:
        if not self.stack:
            return None
        return self.stack.pop()


# =====================================================================
# 6. POWER GRID HIERARCHY -> N-ARY TREE
# =====================================================================
class PowerGridNode:
    """
    Hierarchical Tree Node representing Generation Stations, Substations, and Feeders.
    Cascade Outage: Depth-First Search (DFS) in O(V).
    """
    def __init__(self, node_id: str, name: str, is_online: bool = True):
        self.id = node_id
        self.name = name
        self.is_online = is_online
        self.children: List['PowerGridNode'] = []

    def add_child(self, child: 'PowerGridNode'):
        self.children.append(child)

    def set_cascade_status(self, status: bool):
        """Recursively cascades power state down all child transformers."""
        self.is_online = status
        for child in self.children:
            child.set_cascade_status(status)

    def count_operational(self) -> Tuple[int, int]:
        """Returns (online_count, total_count) across the subtree."""
        online = 1 if self.is_online else 0
        total = 1
        for child in self.children:
            child_online, child_total = child.count_operational()
            online += child_online
            total += child_total
        return online, total


# =====================================================================
# CLI DEMONSTRATION RUNNER
# =====================================================================
def run_smart_city_demo():
    print("=" * 70)
    print("🏙️  SMART CITY SERVICE DASHBOARD - DATA STRUCTURES ENGINE")
    print("=" * 70)

    # 1. Traffic Routing (Graph - Dijkstra)
    print("\n[1] TRAFFIC ROUTING (Graph + Dijkstra's Algorithm)")
    traffic = TrafficGraph()
    traffic.add_road("Downtown Core", "North Hills", 4.0)
    traffic.add_road("Downtown Core", "Civic Square", 3.0)
    traffic.add_road("North Hills", "Airport Junc", 5.0)
    traffic.add_road("Civic Square", "Tech Park", 8.0)
    traffic.add_road("Airport Junc", "Tech Park", 3.0)
    cost, route = traffic.dijkstra_shortest_path("Downtown Core", "Tech Park")
    print(f"    Fastest Emergency Route: {' -> '.join(route)}")
    print(f"    Estimated Travel Time: {cost:.1f} minutes")

    # 2. Emergency 911 Dispatch (Min-Heap)
    print("\n[2] EMERGENCY 911 DISPATCH (Binary Min-Heap Priority Queue)")
    dispatch = EmergencyDispatchQueue()
    dispatch.enqueue_incident(EmergencyIncident("E-1", 3, "Gas Odor Inspection", "Sector 4"))
    dispatch.enqueue_incident(EmergencyIncident("E-2", 1, "Acute Cardiac Arrest", "Downtown"))
    dispatch.enqueue_incident(EmergencyIncident("E-3", 2, "Structure Fire", "Industrial Zone"))
    top = dispatch.dispatch_highest_urgency()
    print(f"    Dispatched Highest Urgency Call: {top}")
    print(f"    Remaining Queued Incidents: {dispatch.size()}")

    # 3. Metro Transit Line (Doubly Linked List)
    print("\n[3] METRO TRANSIT LINE (Doubly Linked List)")
    metro = MetroTransitLine()
    st1 = metro.append_station("Central Terminal", 310)
    st2 = metro.append_station("Civic Square", 240)
    st3 = metro.append_station("Tech Park Terminus", 520)
    metro.move_train_next()
    print(f"    Current Station: {metro.current_train.name}")
    print(f"    Previous Station Pointer: {metro.current_train.prev.name}")
    print(f"    Next Station Pointer: {metro.current_train.next.name}")

    # 4. Asset Registry (Hash Table)
    print("\n[4] MUNICIPAL ASSET REGISTRY (Hash Table with Chaining)")
    registry = MunicipalHashTable(capacity=8)
    registry.set("CITY-9042", {"owner": "Elena Rostova", "type": "Transit Van"})
    registry.set("CITY-1011", {"owner": "David Kim", "type": "Ambulance"})
    plate_data = registry.get("CITY-9042")
    print(f"    Plate 'CITY-9042' Lookup Result: {plate_data}")
    print(f"    Hash Table Load Factor: {registry.load_factor():.2f}")

    # 5. Citizen Service Desk (Queue & Stack)
    print("\n[5] CITIZEN SERVICE DESK (FIFO Queue & LIFO Undo Stack)")
    tokens = CitizenTokenQueue()
    audit = AuditRollbackStack()
    tokens.enqueue("T-101", "Marcus Vance", "Permits")
    tokens.enqueue("T-102", "Aria Thorne", "Water Utility")
    served = tokens.dequeue()
    audit.push_action(f"Approved Permit for {served['name']}", "Officer Diaz")
    print(f"    Served Citizen from FIFO Queue: {served}")
    rolled_back = audit.pop_undo()
    print(f"    LIFO Rollback Executed: {rolled_back}")

    # 6. Power Grid Distribution (N-ary Tree)
    print("\n[6] POWER DISTRIBUTION GRID (Hierarchical Tree)")
    power_plant = PowerGridNode("ROOT", "Metropolitan Hydro Station")
    sub1 = PowerGridNode("SUB-1", "North Substation")
    sub2 = PowerGridNode("SUB-2", "South Substation")
    feeder1 = PowerGridNode("F-1", "Civic Hospital Transformer")
    feeder2 = PowerGridNode("F-2", "Industrial Complex Feeder")
    sub1.add_child(feeder1)
    sub2.add_child(feeder2)
    power_plant.add_child(sub1)
    power_plant.add_child(sub2)

    online_before, total = power_plant.count_operational()
    print(f"    Normal Grid Status: {online_before}/{total} Nodes Online (100%)")
    print("    Simulating Outage at North Substation...")
    sub1.set_cascade_status(False)
    online_after, _ = power_plant.count_operational()
    print(f"    Post-Outage Grid Status: {online_after}/{total} Nodes Online (Hospital disconnected safely)")

    print("\n" + "=" * 70)
    print("✅ All Smart City Data Structures Verified Successfully!")
    print("=" * 70)


if __name__ == "__main__":
    run_smart_city_demo()
