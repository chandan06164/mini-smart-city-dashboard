"""
Unit Tests for Smart City Data Structures Engine
Validates invariant correctness and time-complexity contracts.
"""

import sys
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import unittest
from smart_city import (
    TrafficGraph,
    EmergencyDispatchQueue,
    EmergencyIncident,
    MetroTransitLine,
    MunicipalHashTable,
    CitizenTokenQueue,
    AuditRollbackStack,
    PowerGridNode,
)


class TestSmartCityDSA(unittest.TestCase):

    def test_dijkstra_shortest_path(self):
        graph = TrafficGraph()
        graph.add_road("A", "B", 4)
        graph.add_road("A", "C", 2)
        graph.add_road("B", "D", 5)
        graph.add_road("C", "B", 1)
        graph.add_road("C", "D", 8)
        
        cost, path = graph.dijkstra_shortest_path("A", "D")
        self.assertEqual(cost, 8)  # A -> C -> B -> D = 2 + 1 + 5 = 8
        self.assertEqual(path, ["A", "C", "B", "D"])

    def test_emergency_min_heap_priority(self):
        pq = EmergencyDispatchQueue()
        pq.enqueue_incident(EmergencyIncident("1", 3, "Non-Urgent Cat in Tree", "Zone A"))
        pq.enqueue_incident(EmergencyIncident("2", 1, "Cardiac Arrest", "Zone B"))
        pq.enqueue_incident(EmergencyIncident("3", 2, "Building Smoke", "Zone C"))
        pq.enqueue_incident(EmergencyIncident("4", 1, "Severe Stroke", "Zone D"))

        first = pq.dispatch_highest_urgency()
        second = pq.dispatch_highest_urgency()
        third = pq.dispatch_highest_urgency()
        fourth = pq.dispatch_highest_urgency()

        self.assertEqual(first.priority, 1)
        self.assertEqual(second.priority, 1)
        self.assertEqual(third.priority, 2)
        self.assertEqual(fourth.priority, 3)
        self.assertIsNone(pq.dispatch_highest_urgency())

    def test_doubly_linked_list_metro(self):
        metro = MetroTransitLine()
        s1 = metro.append_station("Station Alpha")
        s2 = metro.append_station("Station Beta")
        s3 = metro.append_station("Station Gamma")

        self.assertEqual(metro.head.name, "Station Alpha")
        self.assertEqual(metro.tail.name, "Station Gamma")

        # Bidirectional pointer check
        self.assertEqual(s2.prev, s1)
        self.assertEqual(s2.next, s3)
        self.assertEqual(s1.next, s2)
        self.assertIsNone(s1.prev)
        self.assertEqual(s3.prev, s2)
        self.assertIsNone(s3.next)

        # Removal check
        metro.remove_station(s2)
        self.assertEqual(s1.next, s3)
        self.assertEqual(s3.prev, s1)

    def test_hash_table_chaining(self):
        ht = MunicipalHashTable(capacity=4)
        ht.set("KEY-A", "Val A")
        ht.set("KEY-B", "Val B")
        ht.set("KEY-C", "Val C")

        self.assertEqual(ht.get("KEY-A"), "Val A")
        self.assertEqual(ht.get("KEY-B"), "Val B")
        self.assertEqual(ht.get("KEY-C"), "Val C")
        self.assertIsNone(ht.get("KEY-NONEXISTENT"))

        # Test update existing key
        ht.set("KEY-A", "Updated A")
        self.assertEqual(ht.get("KEY-A"), "Updated A")

    def test_queue_and_stack(self):
        queue = CitizenTokenQueue()
        stack = AuditRollbackStack()

        queue.enqueue("T1", "Alice", "Dept 1")
        queue.enqueue("T2", "Bob", "Dept 2")

        # FIFO check
        c1 = queue.dequeue()
        c2 = queue.dequeue()
        self.assertEqual(c1["name"], "Alice")
        self.assertEqual(c2["name"], "Bob")
        self.assertTrue(queue.is_empty())

        # LIFO check
        stack.push_action("Action 1", "Admin")
        stack.push_action("Action 2", "Admin")
        self.assertEqual(stack.pop_undo()["action"], "Action 2")
        self.assertEqual(stack.pop_undo()["action"], "Action 1")
        self.assertIsNone(stack.pop_undo())

    def test_power_tree_cascade(self):
        root = PowerGridNode("R", "Root Station")
        c1 = PowerGridNode("C1", "Substation 1")
        c2 = PowerGridNode("C2", "Substation 2")
        leaf = PowerGridNode("L1", "Feeder 1")

        root.add_child(c1)
        root.add_child(c2)
        c1.add_child(leaf)

        online, total = root.count_operational()
        self.assertEqual((online, total), (4, 4))

        # Cascade outage on C1
        c1.set_cascade_status(False)
        self.assertFalse(c1.is_online)
        self.assertFalse(leaf.is_online)
        self.assertTrue(c2.is_online)
        self.assertTrue(root.is_online)

        online, total = root.count_operational()
        self.assertEqual((online, total), (2, 4))


if __name__ == "__main__":
    unittest.main()
