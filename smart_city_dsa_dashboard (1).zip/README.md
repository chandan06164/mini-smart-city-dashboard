# 🏙️ Smart City Operations & Municipal Services Dashboard (Data Structures)

An interactive, high-performance Data Structures & Algorithms (DSA) project demonstrating how core data structures power critical urban infrastructure in modern smart cities.

---

## 🏗️ Architecture & Municipal Services Mapping

| # | Smart City Municipal Service | Core Data Structure | Primary Algorithm | Time Complexity | Real-World Urban Role |
|---|-----------------------------|--------------------|-------------------|-----------------|-----------------------|
| **1** | **Smart Traffic & Navigation** | **Weighted Directed Graph** | Dijkstra's Algorithm | $\mathcal{O}((V + E) \log V)$ | Computes fastest emergency routes and detour paths around traffic bottlenecks. |
| **2** | **911 Emergency Dispatch** | **Binary Min-Heap (Priority Queue)** | Heapify Up / Extract-Min | $\mathcal{O}(\log N)$ | Dispatches highest priority life-threatening calls (Priority 1) before lower codes. |
| **3** | **Metro Express Transit** | **Doubly Linked List (DLL)** | Bidirectional Traversal | $\mathcal{O}(1)$ step | Bidirectional train navigation; insertion and decommission of stations without shifting arrays. |
| **4** | **Vehicle & Asset Registry** | **Hash Table with Chaining** | Polynomial Rolling Hash | $\mathcal{O}(1)$ avg lookup | Ultra-fast plate lookup for automated tolling, speed cameras, and permits. |
| **5** | **Citizen Service Counter & Audit** | **FIFO Queue & LIFO Stack** | Enqueue/Dequeue & Push/Pop | $\mathcal{O}(1)$ | Queue ensures fair token issuance; stack allows administrative rollback & undo. |
| **6** | **Power Distribution Grid** | **Hierarchical N-ary Tree** | Depth-First Search (DFS) | $\mathcal{O}(V + E)$ | Models regional substations and isolates cascading blackout failures safely. |

---

## 📁 Project Structure

```text
smart_city_dsa_dashboard/
├── smart_city.py        # Core DSA implementations (Graph, Heap, DLL, Hash Table, Queue, Stack, Tree)
├── app.py               # Python HTTP REST API & Web Dashboard Server (Zero dependencies)
├── gui_app.py           # Native Desktop GUI (Tkinter + Canvas Visualizers)
├── index.html           # Standalone Interactive HTML5/Canvas Web Dashboard
├── test_smart_city.py   # Comprehensive Unit Test Suite
└── README.md            # System Documentation & Complexity Analysis
```

---

## 🚀 How to Run

### Option 1: Web Dashboard with Live Python Backend (Recommended)
Starts the Python HTTP REST server and launches the dashboard in your default browser:
```powershell
python app.py
```
*Accessible at: `http://127.0.0.1:8000`*

### Option 2: Native Python Desktop GUI (Tkinter)
Runs a native desktop application with tabbed interactive canvases:
```powershell
python gui_app.py
```

### Option 3: Terminal CLI Demonstration
Executes a terminal simulation of all 6 services with metrics output:
```powershell
python smart_city.py
```

### Option 4: Run Automated Unit Tests
Verifies the algorithmic invariants across all data structures:
```powershell
python -m unittest test_smart_city.py
```

---

## 📊 Detailed Complexity Analysis

| Data Structure | Operation | Best Case | Average Case | Worst Case | Space Complexity |
|---|---|---|---|---|---|
| **Graph (Adjacency List)** | Dijkstra's Shortest Path | $\mathcal{O}((V + E) \log V)$ | $\mathcal{O}((V + E) \log V)$ | $\mathcal{O}((V + E) \log V)$ | $\mathcal{O}(V + E)$ |
| **Binary Min-Heap** | Extract-Min (Dispatch) | $\mathcal{O}(1)$ | $\mathcal{O}(\log N)$ | $\mathcal{O}(\log N)$ | $\mathcal{O}(N)$ |
| **Binary Min-Heap** | Enqueue Incident | $\mathcal{O}(1)$ | $\mathcal{O}(\log N)$ | $\mathcal{O}(\log N)$ | $\mathcal{O}(N)$ |
| **Doubly Linked List** | Next / Prev Station Hop | $\mathcal{O}(1)$ | $\mathcal{O}(1)$ | $\mathcal{O}(1)$ | $\mathcal{O}(N)$ |
| **Doubly Linked List** | Delete Known Station Node | $\mathcal{O}(1)$ | $\mathcal{O}(1)$ | $\mathcal{O}(1)$ | $\mathcal{O}(1)$ |
| **Hash Table** | Key Lookup / Insert | $\mathcal{O}(1)$ | $\mathcal{O}(1)$ | $\mathcal{O}(N)$ | $\mathcal{O}(N + B)$ |
| **Queue** | Token Issue (Enqueue) | $\mathcal{O}(1)$ | $\mathcal{O}(1)$ | $\mathcal{O}(1)$ | $\mathcal{O}(K)$ |
| **Stack** | Action Undo (Pop) | $\mathcal{O}(1)$ | $\mathcal{O}(1)$ | $\mathcal{O}(1)$ | $\mathcal{O}(M)$ |
| **Hierarchical Tree** | Subtree Outage Cascade | $\mathcal{O}(1)$ | $\mathcal{O}(K)$ | $\mathcal{O}(V)$ | $\mathcal{O}(\text{Height})$ |

---

## 🎯 Key Design Highlights
- **100% Python Standard Library**: No external third-party dependencies required (`pip` not needed).
- **Dual Visual Frontends**: Both a browser-based UI and a native Tkinter desktop app are included.
- **Academic & Interview Ready**: Clean OOP architecture, type annotations, and full unit test coverage.
