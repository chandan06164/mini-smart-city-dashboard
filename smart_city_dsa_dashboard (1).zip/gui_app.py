"""
Smart City Service Dashboard - Native Python Desktop GUI (Tkinter)
Zero external dependencies. Complete native desktop visualizer for:
1. Traffic Routing (Weighted Graph + Dijkstra)
2. Emergency 911 Dispatch (Binary Min-Heap)
3. Metro Transit Line (Doubly Linked List)
4. Vehicle Registry (Hash Table with Chaining)
5. Citizen Service Desk (FIFO Queue + LIFO Stack)
6. Power Distribution Grid (N-ary Tree + DFS Cascade)
"""

import sys
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

import tkinter as tk
from tkinter import ttk, messagebox
import math

from smart_city import (
    TrafficGraph,
    EmergencyDispatchQueue,
    EmergencyIncident,
    MetroTransitLine,
    MunicipalHashTable,
    CitizenTokenQueue,
    AuditRollbackStack,
    PowerGridNode,
)


class SmartCityGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("SmartCity Operations Engine - Python DSA Dashboard")
        self.geometry("1020x720")
        self.configure(bg="#0f172a")

        # Configure Dark Slate Theme
        self.style = ttk.Style(self)
        self.style.theme_use("clam")
        self.style.configure(".", background="#0f172a", foreground="#f8fafc", font=("Segoe UI", 10))
        self.style.configure("TNotebook", background="#0f172a", borderwidth=0)
        self.style.configure("TNotebook.Tab", background="#1e293b", foreground="#94a3b8", padding=[14, 6], font=("Segoe UI", 10, "bold"))
        self.style.map("TNotebook.Tab", background=[("selected", "#0284c7")], foreground=[("selected", "#ffffff")])
        self.style.configure("TFrame", background="#0f172a")
        self.style.configure("TLabel", background="#0f172a", foreground="#f8fafc")
        self.style.configure("Header.TLabel", font=("Segoe UI", 14, "bold"), foreground="#38bdf8")
        self.style.configure("SubHeader.TLabel", font=("Segoe UI", 9), foreground="#94a3b8")

        # Initialize DSA Engines
        self.init_dsa_models()

        # Top Bar
        top_bar = tk.Frame(self, bg="#1e293b", height=60, padx=16, pady=10)
        top_bar.pack(fill="x", side="top")
        
        lbl_title = tk.Label(top_bar, text="🏙️ SmartCity Operations Engine", font=("Segoe UI", 14, "bold"), bg="#1e293b", fg="#ffffff")
        lbl_title.pack(side="left")

        self.lbl_ops = tk.Label(top_bar, text="Total Operations: 0", font=("Consolas", 10, "bold"), bg="#1e293b", fg="#38bdf8")
        self.lbl_ops.pack(side="right", padx=10)

        # Tabbed Notebook
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=12, pady=12)

        self.tab_traffic = ttk.Frame(self.notebook)
        self.tab_emergency = ttk.Frame(self.notebook)
        self.tab_metro = ttk.Frame(self.notebook)
        self.tab_registry = ttk.Frame(self.notebook)
        self.tab_service = ttk.Frame(self.notebook)
        self.tab_power = ttk.Frame(self.notebook)

        self.notebook.add(self.tab_traffic, text="🚦 1. Traffic (Graph)")
        self.notebook.add(self.tab_emergency, text="🚑 2. 911 Dispatch (Heap)")
        self.notebook.add(self.tab_metro, text="🚇 3. Metro (DLL)")
        self.notebook.add(self.tab_registry, text="🗂️ 4. Registry (Hash)")
        self.notebook.add(self.tab_service, text="🏛️ 5. Service (Queue/Stack)")
        self.notebook.add(self.tab_power, text="⚡ 6. Power Grid (Tree)")

        self.ops_count = 0

        # Build individual tabs
        self.build_traffic_tab()
        self.build_emergency_tab()
        self.build_metro_tab()
        self.build_registry_tab()
        self.build_service_tab()
        self.build_power_tab()

    def inc_ops(self):
        self.ops_count += 1
        self.lbl_ops.config(text=f"Total Operations: {self.ops_count}")

    def init_dsa_models(self):
        # 1. Traffic Graph
        self.graph = TrafficGraph()
        nodes = [("A", "Downtown"), ("B", "North Hills"), ("C", "Civic Sq"), ("D", "Airport"), ("E", "Harbor"), ("F", "Tech Park")]
        for nid, name in nodes:
            self.graph.add_intersection(nid, name)
        self.graph.add_road("A", "B", 4)
        self.graph.add_road("A", "C", 3)
        self.graph.add_road("B", "C", 2)
        self.graph.add_road("B", "D", 5)
        self.graph.add_road("C", "E", 6)
        self.graph.add_road("C", "F", 8)
        self.graph.add_road("D", "F", 3)
        self.graph.add_road("E", "F", 2)
        self.graph_coords = {
            "A": (120, 200),
            "B": (280, 100),
            "C": (280, 300),
            "D": (460, 100),
            "E": (460, 300),
            "F": (620, 200)
        }
        self.active_path = []

        # 2. Emergency Heap
        self.dispatch_pq = EmergencyDispatchQueue()
        self.dispatch_pq.enqueue_incident(EmergencyIncident("E1", 1, "Cardiac Arrest", "Downtown"))
        self.dispatch_pq.enqueue_incident(EmergencyIncident("E2", 2, "Structure Fire", "North"))
        self.dispatch_pq.enqueue_incident(EmergencyIncident("E3", 3, "Gas Smell", "East"))
        self.dispatch_pq.enqueue_incident(EmergencyIncident("E4", 4, "Tree Branch", "South"))
        self.dispatch_pq.enqueue_incident(EmergencyIncident("E5", 2, "Car Crash", "Harbor"))

        # 3. Metro DLL
        self.metro = MetroTransitLine()
        for s in ["Central Terminal", "Civic Center", "Financial District", "West Harbor", "Airport Terminus"]:
            self.metro.append_station(s)

        # 4. Hash Table
        self.registry = MunicipalHashTable(capacity=8)
        self.registry.set("CITY-1011", {"owner": "David Kim", "status": "Emergency Fleet"})
        self.registry.set("CITY-9042", {"owner": "Elena Rostova", "status": "Active Permit"})
        self.registry.set("CITY-3320", {"owner": "Metro Grid Van", "status": "Utility"})
        self.registry.set("CITY-7741", {"owner": "Sarah Jenkins", "status": "EV Exemption"})

        # 5. Service Desk
        self.token_queue = CitizenTokenQueue()
        self.audit_stack = AuditRollbackStack()
        self.token_queue.enqueue("T-101", "Marcus Vance", "Permits")
        self.token_queue.enqueue("T-102", "Aria Thorne", "Water")
        self.token_queue.enqueue("T-103", "Leo Zhang", "Tax")

        # 6. Power Grid Tree
        self.power_root = PowerGridNode("R", "Metropolitan Hydro Plant")
        sub1 = PowerGridNode("S1", "North Substation")
        sub2 = PowerGridNode("S2", "Central Grid")
        sub3 = PowerGridNode("S3", "South Substation")
        sub1.add_child(PowerGridNode("F1", "Residential Feeder A"))
        sub1.add_child(PowerGridNode("F2", "Civic Hospital"))
        sub2.add_child(PowerGridNode("F3", "Downtown Commercial"))
        sub3.add_child(PowerGridNode("F4", "Harbor Yard"))
        sub3.add_child(PowerGridNode("F5", "Tech Cleanrooms"))
        self.power_root.add_child(sub1)
        self.power_root.add_child(sub2)
        self.power_root.add_child(sub3)

    # ----------------------------------------------------
    # TAB 1: TRAFFIC GRAPH (DIJKSTRA)
    # ----------------------------------------------------
    def build_traffic_tab(self):
        f = self.tab_traffic
        ctrl_frame = tk.Frame(f, bg="#1e293b", padx=16, pady=16, width=280)
        ctrl_frame.pack(side="left", fill="y", padx=8, pady=8)

        tk.Label(ctrl_frame, text="Dijkstra Routing Engine", font=("Segoe UI", 12, "bold"), fg="#38bdf8", bg="#1e293b").pack(anchor="w", pady=(0, 4))
        tk.Label(ctrl_frame, text="Graph with Adjacency List: O((V+E) log V)", font=("Segoe UI", 8), fg="#94a3b8", bg="#1e293b").pack(anchor="w", pady=(0, 16))

        tk.Label(ctrl_frame, text="Origin Intersection:", fg="#f8fafc", bg="#1e293b").pack(anchor="w")
        self.combo_start = ttk.Combobox(ctrl_frame, values=["A", "B", "C", "D", "E", "F"], state="readonly")
        self.combo_start.set("A")
        self.combo_start.pack(fill="x", pady=(2, 10))

        tk.Label(ctrl_frame, text="Destination Intersection:", fg="#f8fafc", bg="#1e293b").pack(anchor="w")
        self.combo_dest = ttk.Combobox(ctrl_frame, values=["A", "B", "C", "D", "E", "F"], state="readonly")
        self.combo_dest.set("F")
        self.combo_dest.pack(fill="x", pady=(2, 14))

        btn_run = tk.Button(ctrl_frame, text="🚀 Compute Shortest Path", bg="#0284c7", fg="#ffffff", font=("Segoe UI", 10, "bold"), relief="flat", padx=10, pady=8, command=self.run_traffic_dijkstra)
        btn_run.pack(fill="x", pady=6)

        self.lbl_traffic_res = tk.Label(ctrl_frame, text="Result: Click compute.", fg="#34d399", bg="#1e293b", wraplength=240, justify="left")
        self.lbl_traffic_res.pack(anchor="w", pady=10)

        # Canvas
        self.traffic_canvas = tk.Canvas(f, bg="#020617", highlightthickness=1, highlightbackground="#334155")
        self.traffic_canvas.pack(side="right", fill="both", expand=True, padx=8, pady=8)
        self.draw_traffic_graph()

    def run_traffic_dijkstra(self):
        self.inc_ops()
        start = self.combo_start.get()
        dest = self.combo_dest.get()
        cost, path = self.graph.dijkstra_shortest_path(start, dest)
        self.active_path = path
        self.lbl_traffic_res.config(text=f"Optimal Path: {' ➔ '.join(path)}\nTravel Time: {cost:.1f} mins\nDistance: {cost*1.8:.1f} km")
        self.draw_traffic_graph()

    def draw_traffic_graph(self):
        c = self.traffic_canvas
        c.delete("all")

        # Edges
        drawn = set()
        for u in self.graph.adj_list:
            for v, w in self.graph.adj_list[u]:
                edge_id = tuple(sorted([u, v]))
                if edge_id in drawn:
                    continue
                drawn.add(edge_id)

                is_active = False
                for i in range(len(self.active_path) - 1):
                    if (self.active_path[i] == u and self.active_path[i+1] == v) or (self.active_path[i] == v and self.active_path[i+1] == u):
                        is_active = True
                        break

                x1, y1 = self.graph_coords[u]
                x2, y2 = self.graph_coords[v]
                color = "#22d3ee" if is_active else "#334155"
                width = 4 if is_active else 2
                c.create_line(x1, y1, x2, y2, fill=color, width=width)

                # Weight badge
                mx, my = (x1 + x2) / 2, (y1 + y2) / 2
                c.create_oval(mx-10, my-10, mx+10, my+10, fill="#1e293b", outline="#0284c7")
                c.create_text(mx, my, text=str(int(w)), fill="#ffffff", font=("Consolas", 8, "bold"))

        # Nodes
        for nid, (x, y) in self.graph_coords.items():
            is_in_path = nid in self.active_path
            fill_col = "#0284c7" if is_in_path else "#0f172a"
            outline_col = "#38bdf8" if is_in_path else "#475569"
            c.create_oval(x-22, y-22, x+22, y+22, fill=fill_col, outline=outline_col, width=3)
            c.create_text(x, y, text=nid, fill="#ffffff", font=("Segoe UI", 12, "bold"))
            name = self.graph.intersections.get(nid, "")
            c.create_text(x, y+34, text=name, fill="#94a3b8", font=("Segoe UI", 9))

    # ----------------------------------------------------
    # TAB 2: EMERGENCY 911 (MIN-HEAP)
    # ----------------------------------------------------
    def build_emergency_tab(self):
        f = self.tab_emergency
        ctrl_frame = tk.Frame(f, bg="#1e293b", padx=16, pady=16, width=280)
        ctrl_frame.pack(side="left", fill="y", padx=8, pady=8)

        tk.Label(ctrl_frame, text="911 Triage Engine", font=("Segoe UI", 12, "bold"), fg="#f43f5e", bg="#1e293b").pack(anchor="w", pady=(0, 4))
        tk.Label(ctrl_frame, text="Binary Min-Heap: Extract-Min O(log N)", font=("Segoe UI", 8), fg="#94a3b8", bg="#1e293b").pack(anchor="w", pady=(0, 16))

        tk.Label(ctrl_frame, text="Incident Description:", fg="#f8fafc", bg="#1e293b").pack(anchor="w")
        self.entry_inc_desc = tk.Entry(ctrl_frame, bg="#0f172a", fg="#ffffff", insertbackground="#ffffff")
        self.entry_inc_desc.insert(0, "Highway Collision")
        self.entry_inc_desc.pack(fill="x", pady=(2, 10))

        tk.Label(ctrl_frame, text="Triage Severity Rating:", fg="#f8fafc", bg="#1e293b").pack(anchor="w")
        self.combo_prio = ttk.Combobox(ctrl_frame, values=["1 - Critical / Code Red", "2 - Urgent / Immediate", "3 - Serious / Stable", "4 - Routine"], state="readonly")
        self.combo_prio.set("1 - Critical / Code Red")
        self.combo_prio.pack(fill="x", pady=(2, 14))

        btn_push = tk.Button(ctrl_frame, text="➕ Push Incident to Heap", bg="#f43f5e", fg="#ffffff", font=("Segoe UI", 9, "bold"), relief="flat", pady=6, command=self.push_heap_incident)
        btn_push.pack(fill="x", pady=4)

        btn_pop = tk.Button(ctrl_frame, text="🚨 Dispatch Top Urgency (Extract Min)", bg="#10b981", fg="#ffffff", font=("Segoe UI", 9, "bold"), relief="flat", pady=6, command=self.pop_heap_incident)
        btn_pop.pack(fill="x", pady=4)

        self.lbl_heap_res = tk.Label(ctrl_frame, text="Status: Ready.", fg="#cbd5e1", bg="#1e293b", wraplength=240, justify="left")
        self.lbl_heap_res.pack(anchor="w", pady=10)

        self.heap_canvas = tk.Canvas(f, bg="#020617", highlightthickness=1, highlightbackground="#334155")
        self.heap_canvas.pack(side="right", fill="both", expand=True, padx=8, pady=8)
        self.draw_heap_tree()

    def push_heap_incident(self):
        self.inc_ops()
        desc = self.entry_inc_desc.get().strip() or "Incident"
        prio_text = self.combo_prio.get()
        prio = int(prio_text.split(" - ")[0])
        inc = EmergencyIncident(f"E{len(self.dispatch_pq.heap)+1}", prio, desc, "Zone City")
        self.dispatch_pq.enqueue_incident(inc)
        self.lbl_heap_res.config(text=f"Pushed to Heap: [P{prio}] {desc}")
        self.draw_heap_tree()

    def pop_heap_incident(self):
        self.inc_ops()
        top = self.dispatch_pq.dispatch_highest_urgency()
        if top:
            self.lbl_heap_res.config(text=f"DISPATCHED HIGHEST TRIAGE:\n{top}")
        else:
            self.lbl_heap_res.config(text="Heap is empty. No emergencies.")
        self.draw_heap_tree()

    def draw_heap_tree(self):
        c = self.heap_canvas
        c.delete("all")
        items = self.dispatch_pq.heap
        if not items:
            c.create_text(350, 200, text="Min-Heap is Empty", fill="#64748b", font=("Segoe UI", 14))
            return

        coords = []
        for i in range(len(items)):
            level = int(math.log2(i + 1))
            idx_in_level = i - (2**level - 1)
            total_in_level = 2**level
            y = 50 + level * 75
            x = (700 / (total_in_level + 1)) * (idx_in_level + 1)
            coords.append((x, y))

        for i in range(len(items)):
            left, right = 2*i + 1, 2*i + 2
            if left < len(items):
                c.create_line(coords[i][0], coords[i][1], coords[left][0], coords[left][1], fill="#334155", width=2)
            if right < len(items):
                c.create_line(coords[i][0], coords[i][1], coords[right][0], coords[right][1], fill="#334155", width=2)

        for i, item in enumerate(items):
            x, y = coords[i]
            col = "#e11d48" if item.priority == 1 else "#d97706" if item.priority == 2 else "#2563eb"
            c.create_oval(x-20, y-20, x+20, y+20, fill=col, outline="#ffffff", width=2)
            c.create_text(x, y, text=f"P{item.priority}", fill="#ffffff", font=("Consolas", 10, "bold"))
            c.create_text(x, y+30, text=item.description[:12], fill="#cbd5e1", font=("Segoe UI", 8))

    # ----------------------------------------------------
    # TAB 3: METRO TRANSIT (DLL)
    # ----------------------------------------------------
    def build_metro_tab(self):
        f = self.tab_metro
        top_ctrl = tk.Frame(f, bg="#1e293b", padx=16, pady=12)
        top_ctrl.pack(fill="x", padx=8, pady=8)

        tk.Button(top_ctrl, text="⬅️ Prev Station (node.prev)", bg="#334155", fg="#ffffff", font=("Segoe UI", 9, "bold"), relief="flat", padx=12, pady=6, command=self.metro_prev).pack(side="left", padx=4)
        tk.Button(top_ctrl, text="➡️ Next Station (node.next)", bg="#f59e0b", fg="#0f172a", font=("Segoe UI", 9, "bold"), relief="flat", padx=12, pady=6, command=self.metro_next).pack(side="left", padx=4)

        tk.Button(top_ctrl, text="🗑️ Remove Current Station", bg="#e11d48", fg="#ffffff", font=("Segoe UI", 9, "bold"), relief="flat", padx=12, pady=6, command=self.metro_remove).pack(side="right", padx=4)

        self.metro_canvas = tk.Canvas(f, bg="#020617", highlightthickness=1, highlightbackground="#334155", height=320)
        self.metro_canvas.pack(fill="both", expand=True, padx=8, pady=8)
        self.draw_metro_track()

    def metro_next(self):
        self.inc_ops()
        self.metro.move_train_next()
        self.draw_metro_track()

    def metro_prev(self):
        self.inc_ops()
        self.metro.move_train_prev()
        self.draw_metro_track()

    def metro_remove(self):
        self.inc_ops()
        if self.metro.current_train:
            self.metro.remove_station(self.metro.current_train)
            self.draw_metro_track()

    def draw_metro_track(self):
        c = self.metro_canvas
        c.delete("all")
        curr = self.metro.head
        x = 60
        y = 140

        while curr:
            is_active = (curr == self.metro.current_train)
            bg_col = "#d97706" if is_active else "#1e293b"
            border_col = "#fbbf24" if is_active else "#475569"

            c.create_rectangle(x, y-40, x+120, y+40, fill=bg_col, outline=border_col, width=2)
            c.create_text(x+60, y-15, text="🚅 TRAIN HERE" if is_active else "🚉 STATION", fill="#ffffff", font=("Segoe UI", 8, "bold"))
            c.create_text(x+60, y+6, text=curr.name[:14], fill="#ffffff", font=("Segoe UI", 9, "bold"))
            c.create_text(x+60, y+24, text=f"{curr.commuters_waiting} waiting", fill="#cbd5e1", font=("Segoe UI", 8))

            if curr.next:
                c.create_line(x+120, y-10, x+160, y-10, fill="#f59e0b", width=2, arrow=tk.LAST)
                c.create_line(x+160, y+10, x+120, y+10, fill="#f59e0b", width=2, arrow=tk.LAST)

            x += 160
            curr = curr.next

    # ----------------------------------------------------
    # TAB 4: VEHICLE REGISTRY (HASH TABLE)
    # ----------------------------------------------------
    def build_registry_tab(self):
        f = self.tab_registry
        ctrl_frame = tk.Frame(f, bg="#1e293b", padx=16, pady=16, width=280)
        ctrl_frame.pack(side="left", fill="y", padx=8, pady=8)

        tk.Label(ctrl_frame, text="Asset Hash Table", font=("Segoe UI", 12, "bold"), fg="#c084fc", bg="#1e293b").pack(anchor="w", pady=(0, 4))
        tk.Label(ctrl_frame, text="Chaining Collision Resolution: O(1) Avg", font=("Segoe UI", 8), fg="#94a3b8", bg="#1e293b").pack(anchor="w", pady=(0, 16))

        tk.Label(ctrl_frame, text="License Plate Key:", fg="#f8fafc", bg="#1e293b").pack(anchor="w")
        self.entry_hash_key = tk.Entry(ctrl_frame, bg="#0f172a", fg="#ffffff", insertbackground="#ffffff")
        self.entry_hash_key.insert(0, "CITY-9042")
        self.entry_hash_key.pack(fill="x", pady=(2, 10))

        tk.Label(ctrl_frame, text="Owner / Fleet Info:", fg="#f8fafc", bg="#1e293b").pack(anchor="w")
        self.entry_hash_val = tk.Entry(ctrl_frame, bg="#0f172a", fg="#ffffff", insertbackground="#ffffff")
        self.entry_hash_val.insert(0, "Elena Rostova (Transit)")
        self.entry_hash_val.pack(fill="x", pady=(2, 14))

        btn_set = tk.Button(ctrl_frame, text="💾 Insert into Hash Table", bg="#9333ea", fg="#ffffff", font=("Segoe UI", 9, "bold"), relief="flat", pady=6, command=self.hash_insert)
        btn_set.pack(fill="x", pady=4)

        btn_get = tk.Button(ctrl_frame, text="🔍 Lookup by Key", bg="#334155", fg="#ffffff", font=("Segoe UI", 9, "bold"), relief="flat", pady=6, command=self.hash_lookup)
        btn_get.pack(fill="x", pady=4)

        self.lbl_hash_res = tk.Label(ctrl_frame, text="Status: Ready.", fg="#cbd5e1", bg="#1e293b", wraplength=240, justify="left")
        self.lbl_hash_res.pack(anchor="w", pady=10)

        # Bucket display listbox
        right_frame = tk.Frame(f, bg="#020617", padx=12, pady=12)
        right_frame.pack(side="right", fill="both", expand=True, padx=8, pady=8)

        tk.Label(right_frame, text="Hash Buckets [0 .. 7] & Linked Overflow Chains:", font=("Segoe UI", 10, "bold"), fg="#c084fc", bg="#020617").pack(anchor="w", pady=(0, 8))
        self.txt_hash_buckets = tk.Text(right_frame, bg="#0f172a", fg="#f8fafc", font=("Consolas", 10), insertbackground="#ffffff", relief="flat")
        self.txt_hash_buckets.pack(fill="both", expand=True)
        self.render_hash_buckets()

    def hash_insert(self):
        self.inc_ops()
        key = self.entry_hash_key.get().strip().upper()
        val = self.entry_hash_val.get().strip()
        if key:
            self.registry.set(key, {"owner": val, "status": "Registered"})
            h_idx = self.registry._hash(key)
            self.lbl_hash_res.config(text=f"Inserted '{key}' -> Bucket {h_idx}\nLoad factor: {self.registry.load_factor():.2f}")
            self.render_hash_buckets()

    def hash_lookup(self):
        self.inc_ops()
        key = self.entry_hash_key.get().strip().upper()
        res = self.registry.get(key)
        h_idx = self.registry._hash(key)
        if res:
            messagebox.showinfo("Hash Table Lookup", f"Found in Bucket {h_idx}!\nKey: {key}\nData: {res}")
        else:
            messagebox.showwarning("Not Found", f"Key '{key}' not found in Hash Table (Probed Bucket {h_idx}).")

    def render_hash_buckets(self):
        self.txt_hash_buckets.delete("1.0", tk.END)
        for i, b in enumerate(self.registry.buckets):
            chain = " ➔ ".join([f"[{item.key}: {item.value.get('owner', '')}]" for item in b])
            if not chain:
                chain = "EMPTY (NULL)"
            self.txt_hash_buckets.insert(tk.END, f"Bucket [{i}]: {chain}\n")

    # ----------------------------------------------------
    # TAB 5: SERVICE DESK (QUEUE + STACK)
    # ----------------------------------------------------
    def build_service_tab(self):
        f = self.tab_service
        # Left: Queue
        left_f = tk.Frame(f, bg="#1e293b", padx=16, pady=16)
        left_f.pack(side="left", fill="both", expand=True, padx=8, pady=8)

        tk.Label(left_f, text="Citizen Service Counter", font=("Segoe UI", 12, "bold"), fg="#10b981", bg="#1e293b").pack(anchor="w")
        tk.Label(left_f, text="FIFO Queue (First In, First Out)", font=("Segoe UI", 8), fg="#94a3b8", bg="#1e293b").pack(anchor="w", pady=(0, 10))

        self.entry_citizen = tk.Entry(left_f, bg="#0f172a", fg="#ffffff", insertbackground="#ffffff")
        self.entry_citizen.insert(0, "Sophia Rodriguez")
        self.entry_citizen.pack(fill="x", pady=4)

        btn_q_add = tk.Button(left_f, text="🎟️ Issue Token (Enqueue: O(1))", bg="#059669", fg="#ffffff", font=("Segoe UI", 9, "bold"), relief="flat", pady=6, command=self.service_enqueue)
        btn_q_add.pack(fill="x", pady=4)

        btn_q_serve = tk.Button(left_f, text="✅ Serve Next (Dequeue: O(1))", bg="#334155", fg="#ffffff", font=("Segoe UI", 9, "bold"), relief="flat", pady=6, command=self.service_dequeue)
        btn_q_serve.pack(fill="x", pady=4)

        self.txt_queue = tk.Text(left_f, bg="#0f172a", fg="#a7f3d0", font=("Consolas", 10), height=8, relief="flat")
        self.txt_queue.pack(fill="both", expand=True, pady=8)

        # Right: Stack
        right_f = tk.Frame(f, bg="#1e293b", padx=16, pady=16)
        right_f.pack(side="right", fill="both", expand=True, padx=8, pady=8)

        tk.Label(right_f, text="Audit & Rollback Stack", font=("Segoe UI", 12, "bold"), fg="#818cf8", bg="#1e293b").pack(anchor="w")
        tk.Label(right_f, text="LIFO Stack (Last In, First Out)", font=("Segoe UI", 8), fg="#94a3b8", bg="#1e293b").pack(anchor="w", pady=(0, 10))

        btn_undo = tk.Button(right_f, text="↩️ Undo Last Operation (Stack Pop: O(1))", bg="#4f46e5", fg="#ffffff", font=("Segoe UI", 9, "bold"), relief="flat", pady=6, command=self.service_undo)
        btn_undo.pack(fill="x", pady=4)

        self.txt_stack = tk.Text(right_f, bg="#0f172a", fg="#c7d2fe", font=("Consolas", 10), height=11, relief="flat")
        self.txt_stack.pack(fill="both", expand=True, pady=8)

        self.render_service_desk()

    def service_enqueue(self):
        self.inc_ops()
        name = self.entry_citizen.get().strip() or "Citizen"
        tid = f"T-{len(self.token_queue.items) + 101}"
        self.token_queue.enqueue(tid, name, "General")
        self.render_service_desk()

    def service_dequeue(self):
        self.inc_ops()
        c = self.token_queue.dequeue()
        if c:
            self.audit_stack.push_action(f"Served {c['name']} ({c['id']})", "Agent")
            self.render_service_desk()

    def service_undo(self):
        self.inc_ops()
        act = self.audit_stack.pop_undo()
        if act:
            messagebox.showinfo("LIFO Stack Rollback", f"Rolled back transaction:\n{act['action']}")
            self.render_service_desk()

    def render_service_desk(self):
        self.txt_queue.delete("1.0", tk.END)
        for i, item in enumerate(self.token_queue.items):
            prefix = "➔ FRONT: " if i == 0 else "         "
            self.txt_queue.insert(tk.END, f"{prefix}[{item['id']}] {item['name']} ({item['dept']})\n")

        self.txt_stack.delete("1.0", tk.END)
        for i in range(len(self.audit_stack.stack)-1, -1, -1):
            act = self.audit_stack.stack[i]
            prefix = "🔝 TOP OF STACK: " if i == len(self.audit_stack.stack)-1 else "               "
            self.txt_stack.insert(tk.END, f"{prefix}{act['action']} ({act['operator']})\n")

    # ----------------------------------------------------
    # TAB 6: POWER GRID (TREE)
    # ----------------------------------------------------
    def build_power_tab(self):
        f = self.tab_power
        top_ctrl = tk.Frame(f, bg="#1e293b", padx=16, pady=12)
        top_ctrl.pack(fill="x", padx=8, pady=8)

        tk.Button(top_ctrl, text="⚡ Restore Complete Grid", bg="#10b981", fg="#ffffff", font=("Segoe UI", 9, "bold"), relief="flat", padx=12, pady=6, command=self.power_restore).pack(side="left", padx=4)
        tk.Label(top_ctrl, text="Click any node to toggle power outage (DFS cascade down subtree)", font=("Segoe UI", 9), fg="#94a3b8", bg="#1e293b").pack(side="left", padx=12)

        self.power_canvas = tk.Canvas(f, bg="#020617", highlightthickness=1, highlightbackground="#334155")
        self.power_canvas.pack(fill="both", expand=True, padx=8, pady=8)
        self.power_canvas.bind("<Button-1>", self.power_click)
        self.draw_power_tree()

    def power_restore(self):
        self.inc_ops()
        self.power_root.set_cascade_status(True)
        self.draw_power_tree()

    def power_click(self, event):
        x, y = event.x, event.y
        for node, (nx, ny) in getattr(self, "power_node_coords", {}).items():
            if math.hypot(nx - x, ny - y) < 22:
                self.inc_ops()
                node.set_cascade_status(not node.is_online)
                self.draw_power_tree()
                break

    def draw_power_tree(self):
        c = self.power_canvas
        c.delete("all")
        self.power_node_coords = {}

        # Predefined layout coordinates for clean tree rendering
        coords = {
            "R": (420, 60),
            "S1": (180, 160),
            "S2": (420, 160),
            "S3": (660, 160),
            "F1": (120, 260),
            "F2": (240, 260),
            "F3": (420, 260),
            "F4": (600, 260),
            "F5": (720, 260),
        }

        def draw_links(node):
            nx, ny = coords[node.id]
            self.power_node_coords[node] = (nx, ny)
            for child in node.children:
                cx, cy = coords[child.id]
                col = "#38bdf8" if (node.is_online and child.is_online) else "#ef4444"
                c.create_line(nx, ny, cx, cy, fill=col, width=2)
                draw_links(child)

        draw_links(self.power_root)

        for node, (nx, ny) in self.power_node_coords.items():
            fill_col = "#0284c7" if node.is_online else "#7f1d1d"
            outline_col = "#38bdf8" if node.is_online else "#ef4444"
            c.create_oval(nx-20, ny-20, nx+20, ny+20, fill=fill_col, outline=outline_col, width=2)
            c.create_text(nx, ny, text="⚡" if node.is_online else "✖", fill="#ffffff", font=("Segoe UI", 11, "bold"))
            c.create_text(nx, ny+30, text=node.name[:14], fill="#cbd5e1", font=("Segoe UI", 8))

        online, total = self.power_root.count_operational()
        c.create_text(420, 20, text=f"Grid Integrity: {online}/{total} Online ({int(online/total*100)}%)", fill="#38bdf8", font=("Segoe UI", 11, "bold"))


if __name__ == "__main__":
    app = SmartCityGUI()
    app.mainloop()
